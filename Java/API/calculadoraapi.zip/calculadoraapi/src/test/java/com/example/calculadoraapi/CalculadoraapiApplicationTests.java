package com.example.calculadoraapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
